// MultiVecAdd.cpp
// Main file for multi-GPU simulation using OpenMP
// Focus is on the VecAdd problem, but this can be easily changed.
// M Smith, NCHC (C) msmith@nchc.narl.org.tw

#include "MultiVecAdd_General.h"

int main() {
	int NUM_THREADS;
	int NUM_GPUS = Check_GPU();
	int nthreads, tid;
	
	// Get the number of GPU's available to us
	printf("->Detected %d GPU's available\n", NUM_GPUS);

	#pragma omp parallel private(nthreads, tid)
	{
		// Get the thread ID
		tid = omp_get_thread_num();
		printf("--> Thread %d activated\n", tid);
		if (tid < NUM_GPUS) {
			// Call the function
			printf("--> Thread %d running GPU\n", tid);
			MultiCore_Main(tid);
		} else {

			printf("--> Thread %d twiddling thumbs\n", tid);
		}
	}

}


