// MultiVecAdd_General.cpp
// Contains important non-gpu related functions
// Compiled together with the main cpp code using g++
// Right now, it seems there is no reason to do this.
// However, as codes grow, this area will also.
// M Smith, NCHC (C) msmith@nchc.narl.org.tw

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

extern void SetDevice(int Device);
extern int Check_GPU();
extern void Copy(float *h_A, float *h_B, float *d_A, float *d_B, size_t size);
extern void CopyBack(float *h_A, float *d_A, size_t size);
extern void CallGPU(float *d_A, float *d_B, float *d_C, int n);
extern void Cleanup(float **h_A, float **h_B, float **h_C, float **d_A, float **d_B, float **d_C);
extern void Init(float **h_A, float **h_B, float **h_C, float **d_A, float **d_B, float **d_C, size_t size);
extern void RandomInit(float*, int);

// Local functions Declarations
void MultiCore_Main(int tid);

// Function definition
void MultiCore_Main(int tid) {
	// This is essentially the main() function which we run on each core/thread.
    	float *h_A, *h_B, *h_C;
    	float *d_A, *d_B, *d_C;
    	int N = 50000;
    	size_t size = N * sizeof(float);

	// Set the device 
	SetDevice(tid);
	
	Init(&h_A, &h_B, &h_C, &d_A, &d_B, &d_C, size);

    	// Initialize input vectors
    	RandomInit(h_A, N);
    	RandomInit(h_B, N);

   	// Copy vectors from host memory to device memory
    	Copy(h_A, h_B, d_A, d_B, size);

    	// Call the GPU
    	CallGPU(d_A, d_B, d_C, N);

    	// Copy result from device memory to host memory
   	// h_C contains the result in host memory
    	CopyBack(h_C, d_C, size);    
    
    	// Verify result
    	for (int i = 0; i < 10; i++) {
		  printf("Thread %d: h_A = %g, h_B = %g, h_C = %g\n", tid, h_A[i], h_B[i], h_C[i]);
    	}
    
    	Cleanup(&h_A, &h_B, &h_C, &d_A, &d_B, &d_C);	

}




